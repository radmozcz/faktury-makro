"""
Aplikace pro správu přijatých faktur
Spuštění: python app.py
"""

import os
import json
import sqlite3
import csv
import io
import re
from datetime import datetime, date, timedelta
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment

# ── Pokus o načtení OCR knihoven (nepovinné) ──────────────────────────────────
try:
    import pdfplumber
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False
    print("⚠  pdfplumber není nainstalován – PDF parsing nebude fungovat")

try:
    import pytesseract
    from PIL import Image
    OCR_SUPPORT = True
except ImportError:
    OCR_SUPPORT = False
    print("⚠  pytesseract/Pillow není nainstalován – OCR obrázků nebude fungovat")

# ── Konfigurace ──────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DB_PATH     = os.path.join(BASE_DIR, "faktury.db")
UPLOAD_DIR  = os.path.join(BASE_DIR, "uploads")
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
ALLOWED_EXT = {"pdf", "png", "jpg", "jpeg", "tiff", "bmp"}

os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50 MB

# ── Výchozí konfigurace ───────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "firmy": ["ABC", "XYZ", "DEF"],
    "app_nazev": "Správa faktur"
}

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

# ── Databáze ──────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    """Vytvoří databázové tabulky pokud neexistují."""
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS faktury (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            firma_zkratka   TEXT    NOT NULL,
            dodavatel       TEXT    NOT NULL,
            cislo_faktury   TEXT,
            datum_vystaveni TEXT,
            datum_splatnosti TEXT,
            zpusob_uhrady   TEXT,
            stav            TEXT    DEFAULT 'ceka',   -- ceka / zaplaceno / po_splatnosti
            celkem_s_dph    REAL    DEFAULT 0,
            soubor_cesta    TEXT,
            zdroj           TEXT    DEFAULT 'rucni',  -- makro / rucni
            created_at      TEXT    DEFAULT (datetime('now','localtime'))
        );

        CREATE TABLE IF NOT EXISTS polozky (
            id                    INTEGER PRIMARY KEY AUTOINCREMENT,
            faktura_id            INTEGER NOT NULL REFERENCES faktury(id) ON DELETE CASCADE,
            nazev                 TEXT    NOT NULL,
            mnozstvi              REAL    DEFAULT 1,
            jednotka              TEXT    DEFAULT 'ks',
            cena_za_jednotku_s_dph REAL   DEFAULT 0,
            celkem_s_dph          REAL    DEFAULT 0,
            zbozi_id              INTEGER REFERENCES zbozi(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS zbozi (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            nazev_canonical  TEXT    NOT NULL UNIQUE,
            poznamka         TEXT
        );

        CREATE TABLE IF NOT EXISTS zbozi_aliasy (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            zbozi_id  INTEGER NOT NULL REFERENCES zbozi(id) ON DELETE CASCADE,
            alias     TEXT    NOT NULL UNIQUE
        );
        """)
    print("✓ Databáze inicializována")

# ── Pomocné funkce ────────────────────────────────────────────────────────────
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT

def update_stav_po_splatnosti():
    """Automaticky přepne faktury 'ceka' na 'po_splatnosti' pokud datum splatnosti uplynul."""
    today = date.today().isoformat()
    with get_db() as conn:
        conn.execute("""
            UPDATE faktury SET stav = 'po_splatnosti'
            WHERE stav = 'ceka'
              AND datum_splatnosti IS NOT NULL
              AND datum_splatnosti < ?
        """, (today,))

def recalc_faktura_total(conn, faktura_id):
    """Přepočítá celkovou sumu faktury z položek."""
    row = conn.execute("SELECT SUM(celkem_s_dph) FROM polozky WHERE faktura_id=?", (faktura_id,)).fetchone()
    total = row[0] or 0
    conn.execute("UPDATE faktury SET celkem_s_dph=? WHERE id=?", (total, faktura_id))

# ── MAKRO parser ───────────────────────────────────────────────────────────────
def parse_makro_pdf(filepath):
    """
    Pokusí se extrahovat data z PDF faktury MAKRO pomocí pdfplumber.
    Vrátí slovník s klíči: cislo_faktury, datum_vystaveni, datum_splatnosti,
    zpusob_uhrady, dodavatel, ico_odberatele, celkem_s_dph, polozky[]
    """
    if not PDF_SUPPORT:
        return None, "pdfplumber není nainstalován"

    result = {
        "cislo_faktury": "",
        "datum_vystaveni": "",
        "datum_splatnosti": "",
        "zpusob_uhrady": "",
        "dodavatel": "MAKRO Cash & Carry ČR s.r.o.",
        "ico_odberatele": "",
        "celkem_s_dph": 0,
        "polozky": []
    }

    try:
        with pdfplumber.open(filepath) as pdf:
            full_text = ""
            for page in pdf.pages:
                full_text += (page.extract_text() or "") + "\n"

        lines = full_text.splitlines()

        # Číslo faktury
        for line in lines:
            m = re.search(r"Faktura\s*[čc]\.?\s*/?\s*VS[:\s]+(\S+)", line, re.IGNORECASE)
            if m:
                result["cislo_faktury"] = m.group(1)
                break
            m = re.search(r"Faktura\s*č\.\s*(\d+)", line, re.IGNORECASE)
            if m:
                result["cislo_faktury"] = m.group(1)
                break

        # Data – hledáme formát DD.MM.YYYY
        dates_found = re.findall(r"(\d{2}\.\d{2}\.\d{4})", full_text)
        if len(dates_found) >= 1:
            result["datum_vystaveni"] = _cz_date(dates_found[0])
        if len(dates_found) >= 2:
            result["datum_splatnosti"] = _cz_date(dates_found[1])

        # Způsob úhrady
        m = re.search(r"Způsob úhrady[:\s]+(.+)", full_text, re.IGNORECASE)
        if m:
            result["zpusob_uhrady"] = m.group(1).strip()

        # IČO odběratele
        m = re.search(r"IČO[:\s]+(\d{8})", full_text)
        if m:
            result["ico_odberatele"] = m.group(1)

        # Celkem s DPH
        m = re.search(r"Celkem\s+s\s+DPH[:\s]+([\d\s,\.]+)\s*K[čc]", full_text, re.IGNORECASE)
        if m:
            result["celkem_s_dph"] = _parse_money(m.group(1))

        # Parsování položek – heuristika pro formát MAKRO
        result["polozky"] = _parse_makro_items(lines)

    except Exception as e:
        return None, str(e)

    return result, None


def _parse_makro_items(lines):
    """
    Heuristika: řádky s položkami mají tvar:
      MM_číslo Název BAL cena jedn cena_mu počet_mu celkem_bez celkem_s DPH%
    Sleva je řádek obsahující zápornou hodnotu nebo klíčová slova.
    """
    items = []
    # Hledáme řádky začínající číslem (MM kód)
    item_pattern = re.compile(
        r"^(\d{6,12})\s+(.+?)\s+(PC|KG|BG|KS)\s+.*?([\d\s]+[,\.][\d]+)\s*$", re.IGNORECASE
    )
    sleva_keywords = ["Určeno pro konečnou spotřebu", "KUP VÍCE", "VĚRNOSTNÍ", "SLEVA"]

    for i, line in enumerate(lines):
        # Zkontroluj slevu
        is_sleva = any(kw.upper() in line.upper() for kw in sleva_keywords)
        neg_m = re.search(r"-\s*([\d\s]+[,\.][\d]+)", line)

        if is_sleva and neg_m and items:
            # Odečti slevu od poslední položky
            sleva_val = _parse_money(neg_m.group(1))
            items[-1]["celkem_s_dph"] = max(0, items[-1]["celkem_s_dph"] - sleva_val)
            continue

        # Pokusit se rozebrat řádek položky
        nums = re.findall(r"[\d]+[,\.][\d]+", line)
        if len(nums) >= 2 and re.match(r"^\d{6,}", line.strip()):
            parts = line.split()
            if len(parts) >= 4:
                # Název je mezi kódem a jednotkou
                nazev_parts = []
                jednotka = "ks"
                for j, p in enumerate(parts[1:], 1):
                    if p.upper() in ("PC", "KG", "BG", "KS", "L"):
                        jednotka = p.upper()
                        break
                    nazev_parts.append(p)
                nazev = " ".join(nazev_parts)

                # Cena celkem s DPH – hledáme poslední číslo řádku
                cena_total = _parse_money(nums[-1]) if nums else 0
                mnozstvi = _parse_money(nums[-2]) if len(nums) >= 2 else 1
                cena_jedn = (cena_total / mnozstvi) if mnozstvi else 0

                if nazev and cena_total > 0:
                    items.append({
                        "nazev": nazev,
                        "mnozstvi": mnozstvi,
                        "jednotka": _map_unit(jednotka),
                        "cena_za_jednotku_s_dph": round(cena_jedn, 4),
                        "celkem_s_dph": cena_total
                    })
    return items


def parse_makro_image(filepath):
    """OCR obrázku faktury MAKRO pomocí Tesseract."""
    if not OCR_SUPPORT:
        return None, "pytesseract/Pillow není nainstalován"
    try:
        img = Image.open(filepath)
        text = pytesseract.image_to_string(img, lang="ces")
        lines = text.splitlines()
        result = {
            "cislo_faktury": "",
            "datum_vystaveni": "",
            "datum_splatnosti": "",
            "zpusob_uhrady": "",
            "dodavatel": "MAKRO Cash & Carry ČR s.r.o.",
            "celkem_s_dph": 0,
            "polozky": _parse_makro_items(lines)
        }
        dates = re.findall(r"(\d{2}\.\d{2}\.\d{4})", text)
        if dates:
            result["datum_vystaveni"] = _cz_date(dates[0])
        if len(dates) > 1:
            result["datum_splatnosti"] = _cz_date(dates[1])
        return result, None
    except Exception as e:
        return None, str(e)


def _cz_date(s):
    """Převede DD.MM.YYYY → YYYY-MM-DD pro uložení do DB."""
    try:
        return datetime.strptime(s, "%d.%m.%Y").strftime("%Y-%m-%d")
    except Exception:
        return s

def _parse_money(s):
    """Převede '1 234,56' nebo '1234.56' → float."""
    s = str(s).replace(" ", "").replace(".", "").replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0

def _map_unit(u):
    mapping = {"PC": "ks", "KS": "ks", "KG": "kg", "BG": "bal", "L": "l", "BG": "bal"}
    return mapping.get(u.upper(), u.lower())


# ═══════════════════════════════════════════════════════════════════════════════
#  ROUTES
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/")
def index():
    update_stav_po_splatnosti()
    return render_template("index.html", config=load_config())

# ── API: konfigurace ──────────────────────────────────────────────────────────
@app.route("/api/config", methods=["GET", "POST"])
def api_config():
    if request.method == "GET":
        return jsonify(load_config())
    data = request.json
    cfg = load_config()
    if "firmy" in data:
        cfg["firmy"] = [f.strip().upper() for f in data["firmy"] if f.strip()]
    if "app_nazev" in data:
        cfg["app_nazev"] = data["app_nazev"]
    save_config(cfg)
    return jsonify({"ok": True})

# ── API: dashboard ────────────────────────────────────────────────────────────
@app.route("/api/dashboard")
def api_dashboard():
    update_stav_po_splatnosti()
    firma = request.args.get("firma", "")
    with get_db() as conn:
        # Tento měsíc
        mesic = date.today().strftime("%Y-%m")
        where_firma = "AND firma_zkratka=?" if firma else ""
        params_base = (firma,) if firma else ()

        row = conn.execute(f"""
            SELECT COUNT(*), COALESCE(SUM(celkem_s_dph),0)
            FROM faktury
            WHERE datum_vystaveni LIKE ? {where_firma}
        """, (mesic + "%",) + params_base).fetchone()
        pocet_mesic, vydaje_mesic = row[0], row[1]

        # Po splatnosti
        row2 = conn.execute(f"""
            SELECT COUNT(*), COALESCE(SUM(celkem_s_dph),0)
            FROM faktury WHERE stav='po_splatnosti' {where_firma}
        """, params_base).fetchone()
        pocet_po_spl, castka_po_spl = row2[0], row2[1]

        # Graf – posledních 12 měsíců
        graf = conn.execute(f"""
            SELECT strftime('%Y-%m', datum_vystaveni) as m, COALESCE(SUM(celkem_s_dph),0)
            FROM faktury
            WHERE datum_vystaveni >= date('now','-12 months') {where_firma}
            GROUP BY m ORDER BY m
        """, params_base).fetchall()

        # Poslední faktury
        posledni = conn.execute(f"""
            SELECT id, dodavatel, cislo_faktury, firma_zkratka, datum_vystaveni,
                   datum_splatnosti, celkem_s_dph, stav
            FROM faktury {('WHERE firma_zkratka=?' if firma else '')}
            ORDER BY created_at DESC LIMIT 5
        """, params_base).fetchall()

    return jsonify({
        "vydaje_mesic": round(vydaje_mesic, 2),
        "pocet_mesic": pocet_mesic,
        "pocet_po_splatnosti": pocet_po_spl,
        "castka_po_splatnosti": round(castka_po_spl, 2),
        "graf": [{"mesic": r[0], "castka": round(r[1], 2)} for r in graf],
        "posledni_faktury": [dict(r) for r in posledni]
    })

# ── API: faktury ──────────────────────────────────────────────────────────────
@app.route("/api/faktury")
def api_faktury():
    firma   = request.args.get("firma", "")
    stav    = request.args.get("stav", "")
    od      = request.args.get("od", "")
    do_     = request.args.get("do", "")
    hledat  = request.args.get("q", "")

    clauses = []
    params  = []
    if firma:
        clauses.append("firma_zkratka=?"); params.append(firma)
    if stav:
        clauses.append("stav=?"); params.append(stav)
    if od:
        clauses.append("datum_vystaveni>=?"); params.append(od)
    if do_:
        clauses.append("datum_vystaveni<=?"); params.append(do_)
    if hledat:
        clauses.append("(dodavatel LIKE ? OR cislo_faktury LIKE ?)")
        params += [f"%{hledat}%", f"%{hledat}%"]

    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""

    with get_db() as conn:
        rows = conn.execute(f"""
            SELECT id, firma_zkratka, dodavatel, cislo_faktury,
                   datum_vystaveni, datum_splatnosti, celkem_s_dph, stav, zdroj
            FROM faktury {where}
            ORDER BY datum_vystaveni DESC, created_at DESC
        """, params).fetchall()
        total = conn.execute(f"SELECT COALESCE(SUM(celkem_s_dph),0) FROM faktury {where}", params).fetchone()[0]

    return jsonify({
        "faktury": [dict(r) for r in rows],
        "celkem": round(total, 2)
    })

@app.route("/api/faktury/<int:fid>")
def api_faktura_detail(fid):
    with get_db() as conn:
        f = conn.execute("SELECT * FROM faktury WHERE id=?", (fid,)).fetchone()
        if not f:
            return jsonify({"error": "Nenalezeno"}), 404
        polozky = conn.execute("""
            SELECT p.*, z.nazev_canonical as zbozi_nazev
            FROM polozky p
            LEFT JOIN zbozi z ON z.id = p.zbozi_id
            WHERE p.faktura_id=?
        """, (fid,)).fetchall()
    return jsonify({"faktura": dict(f), "polozky": [dict(p) for p in polozky]})

@app.route("/api/faktury/<int:fid>/stav", methods=["POST"])
def api_faktura_stav(fid):
    stav = request.json.get("stav")
    if stav not in ("ceka", "zaplaceno", "po_splatnosti"):
        return jsonify({"error": "Neplatný stav"}), 400
    with get_db() as conn:
        conn.execute("UPDATE faktury SET stav=? WHERE id=?", (stav, fid))
    return jsonify({"ok": True})

@app.route("/api/faktury/<int:fid>", methods=["DELETE"])
def api_faktura_delete(fid):
    with get_db() as conn:
        row = conn.execute("SELECT soubor_cesta FROM faktury WHERE id=?", (fid,)).fetchone()
        conn.execute("DELETE FROM faktury WHERE id=?", (fid,))
    if row and row["soubor_cesta"]:
        path = os.path.join(UPLOAD_DIR, row["soubor_cesta"])
        if os.path.exists(path):
            os.remove(path)
    return jsonify({"ok": True})

@app.route("/api/faktury/<int:fid>", methods=["PUT"])
def api_faktura_update(fid):
    data = request.json
    fields = ["firma_zkratka","dodavatel","cislo_faktury","datum_vystaveni",
              "datum_splatnosti","zpusob_uhrady","stav"]
    set_parts = [f"{f}=?" for f in fields if f in data]
    vals = [data[f] for f in fields if f in data]
    if not set_parts:
        return jsonify({"ok": True})
    vals.append(fid)
    with get_db() as conn:
        conn.execute(f"UPDATE faktury SET {','.join(set_parts)} WHERE id=?", vals)
    return jsonify({"ok": True})

# ── API: nahrání souboru (MAKRO) ─────────────────────────────────────────────
@app.route("/api/nahrat", methods=["POST"])
def api_nahrat():
    if "soubor" not in request.files:
        return jsonify({"error": "Žádný soubor"}), 400
    f = request.files["soubor"]
    if not f.filename or not allowed_file(f.filename):
        return jsonify({"error": "Nepodporovaný formát"}), 400

    fname  = secure_filename(f.filename)
    ts     = datetime.now().strftime("%Y%m%d_%H%M%S_")
    fname  = ts + fname
    fpath  = os.path.join(UPLOAD_DIR, fname)
    f.save(fpath)

    ext = fname.rsplit(".", 1)[1].lower()
    if ext == "pdf":
        data, err = parse_makro_pdf(fpath)
    else:
        data, err = parse_makro_image(fpath)

    if err:
        return jsonify({"error": err, "soubor_cesta": fname}), 200

    data["soubor_cesta"] = fname
    return jsonify(data)

# ── API: uložení faktury (MAKRO nebo ruční) ───────────────────────────────────
@app.route("/api/faktury", methods=["POST"])
def api_faktura_ulozit():
    data = request.json
    required = ["firma_zkratka", "dodavatel"]
    for r in required:
        if not data.get(r):
            return jsonify({"error": f"Chybí pole: {r}"}), 400

    polozky = data.pop("polozky", [])

    with get_db() as conn:
        cur = conn.execute("""
            INSERT INTO faktury (firma_zkratka, dodavatel, cislo_faktury, datum_vystaveni,
                datum_splatnosti, zpusob_uhrady, stav, celkem_s_dph, soubor_cesta, zdroj)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (
            data.get("firma_zkratka"),
            data.get("dodavatel"),
            data.get("cislo_faktury",""),
            data.get("datum_vystaveni",""),
            data.get("datum_splatnosti",""),
            data.get("zpusob_uhrady",""),
            data.get("stav","ceka"),
            data.get("celkem_s_dph", 0),
            data.get("soubor_cesta",""),
            data.get("zdroj","rucni")
        ))
        faktura_id = cur.lastrowid

        for p in polozky:
            nazev = p.get("nazev","").strip()
            if not nazev:
                continue
            mnozstvi = float(p.get("mnozstvi", 1) or 1)
            celkem   = float(p.get("celkem_s_dph", 0) or 0)
            cena_j   = float(p.get("cena_za_jednotku_s_dph", 0) or 0)
            if cena_j == 0 and mnozstvi:
                cena_j = celkem / mnozstvi
            jed = p.get("jednotka","ks")

            # Slučování zboží – přesná shoda názvu
            zbozi_id = _get_or_create_zbozi(conn, nazev)

            conn.execute("""
                INSERT INTO polozky (faktura_id, nazev, mnozstvi, jednotka,
                    cena_za_jednotku_s_dph, celkem_s_dph, zbozi_id)
                VALUES (?,?,?,?,?,?,?)
            """, (faktura_id, nazev, mnozstvi, jed, round(cena_j,4), round(celkem,2), zbozi_id))

        recalc_faktura_total(conn, faktura_id)

    return jsonify({"ok": True, "id": faktura_id})


def _get_or_create_zbozi(conn, nazev):
    """Vrátí zbozi_id pro daný název (přes alias nebo canonical). Vytvoří nové pokud neexistuje."""
    # Zkus alias
    row = conn.execute("SELECT zbozi_id FROM zbozi_aliasy WHERE alias=?", (nazev,)).fetchone()
    if row:
        return row[0]
    # Zkus canonical
    row = conn.execute("SELECT id FROM zbozi WHERE nazev_canonical=?", (nazev,)).fetchone()
    if row:
        return row[0]
    # Vytvoř nové
    cur = conn.execute("INSERT INTO zbozi (nazev_canonical) VALUES (?)", (nazev,))
    return cur.lastrowid

# ── API: položky / zboží ──────────────────────────────────────────────────────
@app.route("/api/polozky")
def api_polozky():
    firma = request.args.get("firma", "")
    od    = request.args.get("od", "")
    do_   = request.args.get("do", "")

    f_cond = "AND f.firma_zkratka=?" if firma else ""
    od_c   = "AND f.datum_vystaveni>=?" if od else ""
    do_c   = "AND f.datum_vystaveni<=?" if do_ else ""
    params = tuple(v for v in [firma, od, do_] if v)

    with get_db() as conn:
        rows = conn.execute(f"""
            SELECT
                COALESCE(z.nazev_canonical, p.nazev) AS zbozi_nazev,
                z.id AS zbozi_id,
                p.jednotka,
                ROUND(SUM(p.mnozstvi),3)            AS celkove_mnozstvi,
                ROUND(SUM(p.celkem_s_dph),2)        AS celkem_utraceno,
                ROUND(AVG(p.cena_za_jednotku_s_dph),4) AS prumerna_cena,
                COUNT(DISTINCT p.faktura_id)        AS pocet_nakupu,
                GROUP_CONCAT(DISTINCT f.dodavatel)  AS dodavatele
            FROM polozky p
            JOIN faktury f ON f.id = p.faktura_id
            LEFT JOIN zbozi z ON z.id = p.zbozi_id
            WHERE 1=1 {f_cond} {od_c} {do_c}
            GROUP BY COALESCE(z.id, p.nazev)
            ORDER BY celkem_utraceno DESC
        """, params).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/polozky/detail/<int:zbozi_id>")
def api_zbozi_detail(zbozi_id):
    with get_db() as conn:
        zbozi = conn.execute("SELECT * FROM zbozi WHERE id=?", (zbozi_id,)).fetchone()
        if not zbozi:
            return jsonify({"error": "Nenalezeno"}), 404
        aliasy = conn.execute("SELECT alias FROM zbozi_aliasy WHERE zbozi_id=?", (zbozi_id,)).fetchall()
        nakupy = conn.execute("""
            SELECT p.*, f.dodavatel, f.datum_vystaveni, f.firma_zkratka, f.id as faktura_id
            FROM polozky p
            JOIN faktury f ON f.id = p.faktura_id
            WHERE p.zbozi_id=?
            ORDER BY f.datum_vystaveni DESC
        """, (zbozi_id,)).fetchall()
    return jsonify({
        "zbozi": dict(zbozi),
        "aliasy": [r["alias"] for r in aliasy],
        "nakupy": [dict(r) for r in nakupy]
    })

@app.route("/api/zbozi")
def api_zbozi_list():
    with get_db() as conn:
        rows = conn.execute("SELECT id, nazev_canonical FROM zbozi ORDER BY nazev_canonical").fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/zbozi/alias", methods=["POST"])
def api_zbozi_alias():
    """Přiřadí položku (název nebo polozka_id) ke zboží."""
    data = request.json
    zbozi_id   = data.get("zbozi_id")
    alias_text = data.get("alias", "").strip()
    polozka_id = data.get("polozka_id")

    if not zbozi_id or not alias_text:
        return jsonify({"error": "Chybí zbozi_id nebo alias"}), 400

    with get_db() as conn:
        # Přidej alias
        try:
            conn.execute("INSERT INTO zbozi_aliasy (zbozi_id, alias) VALUES (?,?)", (zbozi_id, alias_text))
        except sqlite3.IntegrityError:
            conn.execute("UPDATE zbozi_aliasy SET zbozi_id=? WHERE alias=?", (zbozi_id, alias_text))

        # Přepiš zbozi_id na všech položkách s tímto názvem
        conn.execute("UPDATE polozky SET zbozi_id=? WHERE nazev=?", (zbozi_id, alias_text))

        # Pokud máme konkrétní polozka_id
        if polozka_id:
            conn.execute("UPDATE polozky SET zbozi_id=? WHERE id=?", (zbozi_id, polozka_id))

    return jsonify({"ok": True})

@app.route("/api/zbozi", methods=["POST"])
def api_zbozi_create():
    nazev = request.json.get("nazev_canonical", "").strip()
    if not nazev:
        return jsonify({"error": "Chybí název"}), 400
    with get_db() as conn:
        try:
            cur = conn.execute("INSERT INTO zbozi (nazev_canonical) VALUES (?)", (nazev,))
            return jsonify({"ok": True, "id": cur.lastrowid})
        except sqlite3.IntegrityError:
            row = conn.execute("SELECT id FROM zbozi WHERE nazev_canonical=?", (nazev,)).fetchone()
            return jsonify({"ok": True, "id": row["id"]})

# ── API: statistiky ───────────────────────────────────────────────────────────
@app.route("/api/statistiky")
def api_statistiky():
    firma = request.args.get("firma", "")
    od    = request.args.get("od", date.today().replace(day=1).isoformat())
    do_   = request.args.get("do", date.today().isoformat())

    f_cond  = "AND firma_zkratka=?" if firma else ""
    f_params = (firma,) if firma else ()

    with get_db() as conn:
        # Výdaje po měsících
        mesice = conn.execute(f"""
            SELECT strftime('%Y-%m', datum_vystaveni) m, ROUND(SUM(celkem_s_dph),2) castka
            FROM faktury
            WHERE datum_vystaveni>=? AND datum_vystaveni<=? {f_cond}
            GROUP BY m ORDER BY m
        """, (od, do_) + f_params).fetchall()

        # Top dodavatelé
        dodavatele = conn.execute(f"""
            SELECT dodavatel, ROUND(SUM(celkem_s_dph),2) castka, COUNT(*) pocet
            FROM faktury
            WHERE datum_vystaveni>=? AND datum_vystaveni<=? {f_cond}
            GROUP BY dodavatel ORDER BY castka DESC LIMIT 10
        """, (od, do_) + f_params).fetchall()

        # Top zboží
        zbozi_top = conn.execute(f"""
            SELECT COALESCE(z.nazev_canonical, p.nazev) zbozi, ROUND(SUM(p.celkem_s_dph),2) castka,
                   ROUND(SUM(p.mnozstvi),2) mnozstvi, p.jednotka
            FROM polozky p
            JOIN faktury f ON f.id=p.faktura_id
            LEFT JOIN zbozi z ON z.id=p.zbozi_id
            WHERE f.datum_vystaveni>=? AND f.datum_vystaveni<=? {f_cond}
            GROUP BY COALESCE(z.id, p.nazev) ORDER BY castka DESC LIMIT 20
        """, (od, do_) + f_params).fetchall()

        # Vývoj ceny vybraného zboží
        zbozi_id = request.args.get("zbozi_id")
        cena_vyvoj = []
        if zbozi_id:
            cena_vyvoj = conn.execute(f"""
                SELECT f.datum_vystaveni dat, ROUND(p.cena_za_jednotku_s_dph,4) cena, f.dodavatel
                FROM polozky p JOIN faktury f ON f.id=p.faktura_id
                WHERE p.zbozi_id=? AND f.datum_vystaveni>=? AND f.datum_vystaveni<=? {f_cond}
                ORDER BY f.datum_vystaveni
            """, (zbozi_id, od, do_) + f_params).fetchall()

    return jsonify({
        "mesice": [dict(r) for r in mesice],
        "dodavatele": [dict(r) for r in dodavatele],
        "zbozi_top": [dict(r) for r in zbozi_top],
        "cena_vyvoj": [dict(r) for r in cena_vyvoj]
    })

# ── API: export ───────────────────────────────────────────────────────────────
@app.route("/api/export/faktury")
def export_faktury():
    fmt   = request.args.get("format", "xlsx")
    firma = request.args.get("firma", "")
    stav  = request.args.get("stav", "")
    od    = request.args.get("od", "")
    do_   = request.args.get("do", "")

    clauses, params = [], []
    if firma: clauses.append("firma_zkratka=?"); params.append(firma)
    if stav:  clauses.append("stav=?"); params.append(stav)
    if od:    clauses.append("datum_vystaveni>=?"); params.append(od)
    if do_:   clauses.append("datum_vystaveni<=?"); params.append(do_)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""

    with get_db() as conn:
        rows = conn.execute(f"""
            SELECT firma_zkratka, dodavatel, cislo_faktury, datum_vystaveni,
                   datum_splatnosti, zpusob_uhrady, stav, celkem_s_dph
            FROM faktury {where} ORDER BY datum_vystaveni DESC
        """, params).fetchall()

    headers = ["Firma", "Dodavatel", "Číslo faktury", "Datum vystavení",
               "Datum splatnosti", "Způsob úhrady", "Stav", "Celkem s DPH"]

    if fmt == "csv":
        buf = io.StringIO()
        w   = csv.writer(buf, delimiter=";")
        w.writerow(headers)
        for r in rows:
            w.writerow(list(r))
        buf.seek(0)
        return send_file(io.BytesIO(buf.getvalue().encode("utf-8-sig")),
                         mimetype="text/csv",
                         download_name="faktury.csv",
                         as_attachment=True)
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Faktury"
        _xlsx_header(ws, headers)
        for r in rows:
            ws.append(list(r))
        buf = io.BytesIO()
        wb.save(buf); buf.seek(0)
        return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         download_name="faktury.xlsx", as_attachment=True)

@app.route("/api/export/polozky")
def export_polozky():
    fmt   = request.args.get("format", "xlsx")
    firma = request.args.get("firma", "")
    od    = request.args.get("od", "")
    do_   = request.args.get("do", "")

    f_cond = "AND f.firma_zkratka=?" if firma else ""
    od_c   = "AND f.datum_vystaveni>=?" if od else ""
    do_c   = "AND f.datum_vystaveni<=?" if do_ else ""
    params = tuple(v for v in [firma, od, do_] if v)

    with get_db() as conn:
        rows = conn.execute(f"""
            SELECT COALESCE(z.nazev_canonical, p.nazev), p.jednotka,
                   ROUND(SUM(p.mnozstvi),3), ROUND(SUM(p.celkem_s_dph),2),
                   ROUND(AVG(p.cena_za_jednotku_s_dph),4),
                   COUNT(DISTINCT p.faktura_id),
                   GROUP_CONCAT(DISTINCT f.dodavatel)
            FROM polozky p JOIN faktury f ON f.id=p.faktura_id
            LEFT JOIN zbozi z ON z.id=p.zbozi_id
            WHERE 1=1 {f_cond} {od_c} {do_c}
            GROUP BY COALESCE(z.id, p.nazev)
            ORDER BY SUM(p.celkem_s_dph) DESC
        """, params).fetchall()

    headers = ["Zboží", "Jednotka", "Celkové množství", "Celkem s DPH",
               "Průměrná cena/jedn.", "Počet nákupů", "Dodavatelé"]

    if fmt == "csv":
        buf = io.StringIO()
        w   = csv.writer(buf, delimiter=";")
        w.writerow(headers)
        for r in rows: w.writerow(list(r))
        buf.seek(0)
        return send_file(io.BytesIO(buf.getvalue().encode("utf-8-sig")),
                         mimetype="text/csv", download_name="polozky.csv", as_attachment=True)
    else:
        wb = openpyxl.Workbook()
        ws = wb.active; ws.title = "Položky"
        _xlsx_header(ws, headers)
        for r in rows: ws.append(list(r))
        buf = io.BytesIO(); wb.save(buf); buf.seek(0)
        return send_file(buf, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                         download_name="polozky.xlsx", as_attachment=True)

def _xlsx_header(ws, headers):
    green = "2D6A4F"
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor=green)
        cell.alignment = Alignment(horizontal="center")

# ── Statické soubory faktur ───────────────────────────────────────────────────
@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)

# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    print("=" * 55)
    print("  Správa faktur – spouštím server")
    print("  Otevři prohlížeč na: http://localhost:5000")
    print("=" * 55)
    app.run(host="0.0.0.0", port=5000, debug=False)
