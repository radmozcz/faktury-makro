/**
 * Správa faktur – hlavní JavaScript (SPA)
 * Žádný framework, čistý vanilla JS
 */

// ═══════════════════════════════════════════════════════════════
//  Globální stav
// ═══════════════════════════════════════════════════════════════
const App = {
  config: { firmy: [], app_nazev: "Správa faktur" },
  currentPage: "dashboard",
  chartInstances: {},   // ukládáme Chart.js instance aby šly zničit
};

// ═══════════════════════════════════════════════════════════════
//  Inicializace
// ═══════════════════════════════════════════════════════════════
document.addEventListener("DOMContentLoaded", async () => {
  loadTheme();
  showDate();
  await loadConfig();
  setupNav();
  setupThemeSwitch();
  setupMobileMenu();
  navigateTo("dashboard");
});

async function loadConfig() {
  const cfg = await api("/api/config");
  App.config = cfg;
  document.getElementById("appNazev").textContent = cfg.app_nazev;
  document.title = cfg.app_nazev;
  fillFirmaSelects();
}

function fillFirmaSelects() {
  const selects = document.querySelectorAll(".firma-select, #globalFirmaFilter");
  selects.forEach(sel => {
    const val = sel.value;
    sel.innerHTML = `<option value="">Všechny firmy</option>` +
      App.config.firmy.map(f => `<option value="${f}">${f}</option>`).join("");
    if (val) sel.value = val;
  });
}

// ═══════════════════════════════════════════════════════════════
//  Navigace
// ═══════════════════════════════════════════════════════════════
function setupNav() {
  document.querySelectorAll(".nav-item").forEach(a => {
    a.addEventListener("click", e => {
      e.preventDefault();
      navigateTo(a.dataset.page);
      // Zavři sidebar na mobilu
      document.getElementById("sidebar").classList.remove("open");
    });
  });
}

function navigateTo(page) {
  App.currentPage = page;
  document.querySelectorAll(".nav-item").forEach(a => {
    a.classList.toggle("active", a.dataset.page === page);
  });
  const pages = {
    dashboard:  renderDashboard,
    faktury:    renderFaktury,
    nahrat:     renderNahrat,
    rucni:      renderRucni,
    polozky:    renderPolozky,
    statistiky: renderStatistiky,
    nastaveni:  renderNastaveni,
  };
  if (pages[page]) pages[page]();
}

// ═══════════════════════════════════════════════════════════════
//  Téma
// ═══════════════════════════════════════════════════════════════
function loadTheme() {
  const t = localStorage.getItem("theme") || "light";
  document.documentElement.setAttribute("data-theme", t);
}
function setupThemeSwitch() {
  const sw = document.getElementById("themeSwitch");
  sw.checked = (document.documentElement.getAttribute("data-theme") === "dark");
  sw.addEventListener("change", () => {
    const t = sw.checked ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", t);
    localStorage.setItem("theme", t);
    // Překresli grafy pokud existují
    Object.values(App.chartInstances).forEach(c => { if (c) c.destroy(); });
    App.chartInstances = {};
    navigateTo(App.currentPage);
  });
}
function setupMobileMenu() {
  document.getElementById("menuBtn").addEventListener("click", () => {
    document.getElementById("sidebar").classList.toggle("open");
  });
}
function showDate() {
  document.getElementById("todayDate").textContent =
    new Date().toLocaleDateString("cs-CZ", { day:"2-digit", month:"long", year:"numeric" });
}

// ═══════════════════════════════════════════════════════════════
//  API helper
// ═══════════════════════════════════════════════════════════════
async function api(url, opts = {}) {
  try {
    const r = await fetch(url, opts);
    if (!r.ok) { const e = await r.json().catch(() => ({})); throw new Error(e.error || r.statusText); }
    return r.json();
  } catch (e) {
    toast("Chyba: " + e.message, true);
    throw e;
  }
}

// ═══════════════════════════════════════════════════════════════
//  Toast notifikace
// ═══════════════════════════════════════════════════════════════
function toast(msg, error = false) {
  const el = document.createElement("div");
  el.className = "toast" + (error ? " error" : "");
  el.textContent = msg;
  document.getElementById("toastContainer").appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ═══════════════════════════════════════════════════════════════
//  Modal
// ═══════════════════════════════════════════════════════════════
function openModal(title, bodyHtml) {
  document.getElementById("modalTitle").textContent = title;
  document.getElementById("modalBody").innerHTML = bodyHtml;
  document.getElementById("modalOverlay").style.display = "flex";
}
function closeModal() {
  document.getElementById("modalOverlay").style.display = "none";
}
document.getElementById("modalClose").addEventListener("click", closeModal);
document.getElementById("modalOverlay").addEventListener("click", e => {
  if (e.target === document.getElementById("modalOverlay")) closeModal();
});

// ═══════════════════════════════════════════════════════════════
//  Formátování
// ═══════════════════════════════════════════════════════════════
function czMoney(v) {
  return Number(v).toLocaleString("cs-CZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " Kč";
}
function czDate(s) {
  if (!s) return "—";
  const d = new Date(s);
  if (isNaN(d)) return s;
  return d.toLocaleDateString("cs-CZ");
}
function stavBadge(s) {
  const m = { zaplaceno: "Zaplaceno", ceka: "Čeká", po_splatnosti: "Po splatnosti" };
  return `<span class="badge badge-${s}">${m[s] || s}</span>`;
}

// ═══════════════════════════════════════════════════════════════
//  Grafy (nativní canvas – bez Chart.js závislosti)
//  Použijeme jednoduchou interní implementaci
// ═══════════════════════════════════════════════════════════════
function drawBarChart(canvasId, labels, values, color) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.width  = canvas.offsetWidth;
  const H = canvas.height = canvas.offsetHeight || 260;
  ctx.clearRect(0, 0, W, H);

  if (!values.length) {
    ctx.fillStyle = "#aaa";
    ctx.font = "14px DM Sans";
    ctx.textAlign = "center";
    ctx.fillText("Žádná data", W/2, H/2);
    return;
  }

  const isDark = document.documentElement.getAttribute("data-theme") === "dark";
  const txtColor = isDark ? "#A8C4A2" : "#6B6255";
  const gridColor = isDark ? "#2F3D34" : "#E0D8CC";

  const pad = { top: 20, right: 20, bottom: 50, left: 70 };
  const maxVal = Math.max(...values, 1);
  const bw = (W - pad.left - pad.right) / values.length;

  // grid lines
  ctx.strokeStyle = gridColor;
  ctx.lineWidth = 1;
  const steps = 5;
  for (let i = 0; i <= steps; i++) {
    const y = pad.top + (H - pad.top - pad.bottom) * (1 - i/steps);
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(W - pad.right, y); ctx.stroke();
    ctx.fillStyle = txtColor;
    ctx.font = "11px DM Sans";
    ctx.textAlign = "right";
    const v = (maxVal * i / steps);
    ctx.fillText(v >= 1000 ? Math.round(v/1000)+"k" : Math.round(v), pad.left - 6, y + 4);
  }

  // bars
  values.forEach((v, i) => {
    const barH = ((v / maxVal) * (H - pad.top - pad.bottom));
    const x = pad.left + i * bw + bw * .1;
    const y = pad.top + (H - pad.top - pad.bottom) - barH;
    const grad = ctx.createLinearGradient(0, y, 0, y + barH);
    grad.addColorStop(0, color || "#52B788");
    grad.addColorStop(1, color ? color + "99" : "#2D6A4F");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(x, y, bw * .8, barH, [4, 4, 0, 0]);
    ctx.fill();

    // label
    ctx.fillStyle = txtColor;
    ctx.font = "10px DM Sans";
    ctx.textAlign = "center";
    const lbl = labels[i] || "";
    ctx.fillText(lbl.length > 7 ? lbl.slice(5) : lbl, pad.left + i * bw + bw/2, H - pad.bottom + 16);
  });
}

function drawLineChart(canvasId, labels, datasets) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.width  = canvas.offsetWidth;
  const H = canvas.height = canvas.offsetHeight || 220;
  ctx.clearRect(0, 0, W, H);

  const isDark = document.documentElement.getAttribute("data-theme") === "dark";
  const txtColor = isDark ? "#A8C4A2" : "#6B6255";
  const gridColor = isDark ? "#2F3D34" : "#E0D8CC";

  const pad = { top: 20, right: 20, bottom: 50, left: 70 };
  const allVals = datasets.flatMap(d => d.values);
  const maxVal  = Math.max(...allVals, 1);
  const minVal  = Math.min(...allVals.filter(v=>v>0), 0);
  const range   = maxVal - minVal || 1;
  const n       = labels.length;

  const getX = i => pad.left + (i / (n-1 || 1)) * (W - pad.left - pad.right);
  const getY = v => pad.top + (1 - (v - minVal) / range) * (H - pad.top - pad.bottom);

  // grid
  ctx.strokeStyle = gridColor;
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = pad.top + i/4 * (H - pad.top - pad.bottom);
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(W - pad.right, y); ctx.stroke();
    ctx.fillStyle = txtColor; ctx.font = "11px DM Sans"; ctx.textAlign = "right";
    const v = maxVal - (maxVal - minVal)*i/4;
    ctx.fillText(v.toFixed(1), pad.left - 6, y + 4);
  }

  // lines
  const colors = ["#2D6A4F", "#E9C46A", "#C44D58", "#52B788"];
  datasets.forEach((ds, di) => {
    if (!ds.values.length) return;
    ctx.strokeStyle = colors[di % colors.length];
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ds.values.forEach((v, i) => {
      const x = getX(i), y = getY(v);
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    // dots
    ctx.fillStyle = colors[di % colors.length];
    ds.values.forEach((v, i) => {
      ctx.beginPath();
      ctx.arc(getX(i), getY(v), 4, 0, 2*Math.PI);
      ctx.fill();
    });
  });

  // x labels
  ctx.fillStyle = txtColor; ctx.font = "10px DM Sans"; ctx.textAlign = "center";
  labels.forEach((lbl, i) => {
    ctx.fillText(lbl, getX(i), H - pad.bottom + 16);
  });
}

// ═══════════════════════════════════════════════════════════════
//  DASHBOARD
// ═══════════════════════════════════════════════════════════════
async function renderDashboard() {
  const firma = document.getElementById("globalFirmaFilter")?.value || "";
  const qs = firma ? `?firma=${firma}` : "";
  document.getElementById("mainContent").innerHTML = `<div class="loading-center"><span class="spinner"></span></div>`;

  let data;
  try { data = await api(`/api/dashboard${qs}`); } catch { return; }

  document.getElementById("mainContent").innerHTML = `
    <div class="page-header">
      <h1 class="page-title">Dashboard</h1>
    </div>
    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-label">Výdaje tento měsíc</div>
        <div class="stat-value">${czMoney(data.vydaje_mesic)}</div>
        <div class="stat-sub">${data.pocet_mesic} faktur</div>
      </div>
      <div class="stat-card ${data.pocet_po_splatnosti > 0 ? 'danger' : ''}">
        <div class="stat-label">Po splatnosti</div>
        <div class="stat-value">${data.pocet_po_splatnosti}</div>
        <div class="stat-sub">${czMoney(data.castka_po_splatnosti)}</div>
      </div>
    </div>
    <div class="grid-2" style="gap:1rem; margin-bottom:1rem;">
      <div class="card">
        <div class="card-title">Výdaje po měsících</div>
        <div class="chart-wrap"><canvas id="barChart"></canvas></div>
      </div>
      <div class="card">
        <div class="card-title">Poslední faktury</div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Dodavatel</th><th>Datum</th><th>Částka</th><th>Stav</th></tr></thead>
            <tbody>
              ${data.posledni_faktury.map(f => `
                <tr data-id="${f.id}" class="faktura-row">
                  <td>${f.dodavatel}</td>
                  <td>${czDate(f.datum_vystaveni)}</td>
                  <td><strong>${czMoney(f.celkem_s_dph)}</strong></td>
                  <td>${stavBadge(f.stav)}</td>
                </tr>`).join("") || "<tr><td colspan='4' style='text-align:center;color:var(--txt2);padding:2rem'>Žádné faktury</td></tr>"}
            </tbody>
          </table>
        </div>
        <div style="margin-top:.8rem;text-align:right">
          <button class="btn btn-secondary btn-sm" onclick="navigateTo('faktury')">Všechny faktury →</button>
        </div>
      </div>
    </div>`;

  // Klik na řádek faktury → detail
  document.querySelectorAll(".faktura-row").forEach(r => {
    r.addEventListener("click", () => openFakturaDetail(r.dataset.id));
  });

  // Graf
  const labels = data.graf.map(g => g.mesic);
  const values = data.graf.map(g => g.castka);
  requestAnimationFrame(() => drawBarChart("barChart", labels, values, "#2D6A4F"));
}

// Při změně globálního filtru firmy → znovu vykresli dashboard
document.getElementById("globalFirmaFilter").addEventListener("change", () => {
  fillFirmaSelects();
  if (App.currentPage === "dashboard") renderDashboard();
});

// ═══════════════════════════════════════════════════════════════
//  FAKTURY
// ═══════════════════════════════════════════════════════════════
async function renderFaktury() {
  document.getElementById("mainContent").innerHTML = `
    <div class="page-header">
      <h1 class="page-title">Faktury</h1>
      <div class="btn-group">
        <button class="btn btn-secondary btn-sm" onclick="exportFaktury('xlsx')">⬇ Excel</button>
        <button class="btn btn-secondary btn-sm" onclick="exportFaktury('csv')">⬇ CSV</button>
      </div>
    </div>
    <div class="filters">
      <label>Firma:</label>
      <select id="fFirma" class="firma-select">
        <option value="">Všechny</option>
        ${App.config.firmy.map(f=>`<option>${f}</option>`).join("")}
      </select>
      <label>Stav:</label>
      <select id="fStav">
        <option value="">Vše</option>
        <option value="ceka">Čeká</option>
        <option value="zaplaceno">Zaplaceno</option>
        <option value="po_splatnosti">Po splatnosti</option>
      </select>
      <label>Od:</label><input type="date" id="fOd">
      <label>Do:</label><input type="date" id="fDo">
      <input type="text" id="fQ" placeholder="Hledat dodavatele/č. faktury..." style="min-width:200px">
    </div>
    <div class="card">
      <div class="table-wrap" id="fakturyTable"><div class="loading-center"><span class="spinner"></span></div></div>
    </div>`;

  // Načti a zobraz
  loadFaktury();

  // Filtry – debounce
  ["fFirma","fStav","fOd","fDo"].forEach(id => {
    document.getElementById(id)?.addEventListener("change", loadFaktury);
  });
  let qdeb;
  document.getElementById("fQ")?.addEventListener("input", () => {
    clearTimeout(qdeb); qdeb = setTimeout(loadFaktury, 350);
  });
}

async function loadFaktury() {
  const params = new URLSearchParams({
    firma: document.getElementById("fFirma")?.value || "",
    stav:  document.getElementById("fStav")?.value  || "",
    od:    document.getElementById("fOd")?.value    || "",
    do:    document.getElementById("fDo")?.value    || "",
    q:     document.getElementById("fQ")?.value     || "",
  });

  let data;
  try { data = await api(`/api/faktury?${params}`); } catch { return; }

  const tbl = document.getElementById("fakturyTable");
  if (!tbl) return;

  tbl.innerHTML = `
    <table>
      <thead><tr>
        <th>Firma</th><th>Dodavatel</th><th>Č. faktury</th>
        <th>Vystavení</th><th>Splatnost</th><th>Celkem s DPH</th><th>Stav</th>
      </tr></thead>
      <tbody>
        ${data.faktury.map(f => `
          <tr class="faktura-row" data-id="${f.id}">
            <td><span class="badge badge-zaplaceno" style="background:var(--green-pale)">${f.firma_zkratka}</span></td>
            <td>${escHtml(f.dodavatel)}</td>
            <td>${escHtml(f.cislo_faktury||"—")}</td>
            <td>${czDate(f.datum_vystaveni)}</td>
            <td>${czDate(f.datum_splatnosti)}</td>
            <td><strong>${czMoney(f.celkem_s_dph)}</strong></td>
            <td>${stavBadge(f.stav)}</td>
          </tr>`).join("") ||
          "<tr><td colspan='7' style='text-align:center;color:var(--txt2);padding:2rem'>Žádné faktury</td></tr>"}
      </tbody>
      ${data.faktury.length ? `
      <tfoot>
        <tr class="table-footer">
          <td colspan="5">Celkem (${data.faktury.length} faktur)</td>
          <td colspan="2"><strong>${czMoney(data.celkem)}</strong></td>
        </tr>
      </tfoot>` : ""}
    </table>`;

  document.querySelectorAll(".faktura-row").forEach(r => {
    r.addEventListener("click", () => openFakturaDetail(r.dataset.id));
  });
}

async function openFakturaDetail(id) {
  let data;
  try { data = await api(`/api/faktury/${id}`); } catch { return; }
  const f = data.faktura;
  const polozky = data.polozky;

  const body = `
    <div class="grid-2" style="gap:1rem; margin-bottom:1rem;">
      <div>
        <div class="form-group"><div class="form-label">Dodavatel</div><strong>${escHtml(f.dodavatel)}</strong></div>
        <div class="form-group"><div class="form-label">Číslo faktury</div>${escHtml(f.cislo_faktury||"—")}</div>
        <div class="form-group"><div class="form-label">Firma</div>${f.firma_zkratka}</div>
        <div class="form-group"><div class="form-label">Zdroj</div>${f.zdroj === "makro" ? "MAKRO (automaticky)" : "Ruční zadání"}</div>
      </div>
      <div>
        <div class="form-group"><div class="form-label">Datum vystavení</div>${czDate(f.datum_vystaveni)}</div>
        <div class="form-group"><div class="form-label">Datum splatnosti</div>${czDate(f.datum_splatnosti)}</div>
        <div class="form-group"><div class="form-label">Způsob úhrady</div>${escHtml(f.zpusob_uhrady||"—")}</div>
        <div class="form-group">
          <div class="form-label">Stav</div>
          <select id="detailStav" class="form-control" style="max-width:200px">
            <option value="ceka" ${f.stav==="ceka"?"selected":""}>Čeká na zaplacení</option>
            <option value="zaplaceno" ${f.stav==="zaplaceno"?"selected":""}>Zaplaceno</option>
            <option value="po_splatnosti" ${f.stav==="po_splatnosti"?"selected":""}>Po splatnosti</option>
          </select>
        </div>
      </div>
    </div>
    ${f.soubor_cesta ? `<div style="margin-bottom:1rem"><a href="/uploads/${f.soubor_cesta}" target="_blank" class="btn btn-secondary btn-sm">📎 Zobrazit originál</a></div>` : ""}
    <h4 style="font-family:var(--font-head);margin-bottom:.7rem">Položky</h4>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Název</th><th>Množství</th><th>Jednotka</th><th>Cena/jedn.</th><th>Celkem s DPH</th></tr></thead>
        <tbody>
          ${polozky.map(p => `
            <tr>
              <td>${escHtml(p.zbozi_nazev || p.nazev)}</td>
              <td>${Number(p.mnozstvi).toLocaleString("cs-CZ")}</td>
              <td>${p.jednotka}</td>
              <td>${czMoney(p.cena_za_jednotku_s_dph)}</td>
              <td><strong>${czMoney(p.celkem_s_dph)}</strong></td>
            </tr>`).join("") || "<tr><td colspan='5' style='text-align:center;color:var(--txt2)'>Žádné položky</td></tr>"}
        </tbody>
        ${polozky.length ? `
        <tfoot>
          <tr class="table-footer">
            <td colspan="4">Celkem s DPH</td>
            <td><strong>${czMoney(f.celkem_s_dph)}</strong></td>
          </tr>
        </tfoot>` : ""}
      </table>
    </div>
    <div class="btn-group" style="margin-top:1rem">
      <button class="btn btn-primary" onclick="saveStav(${f.id})">💾 Uložit stav</button>
      <button class="btn btn-danger btn-sm" onclick="deleteFaktura(${f.id})">🗑 Smazat</button>
    </div>`;

  openModal(`Faktura – ${escHtml(f.dodavatel)} ${czDate(f.datum_vystaveni)}`, body);
}

async function saveStav(id) {
  const stav = document.getElementById("detailStav").value;
  await api(`/api/faktury/${id}/stav`, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({ stav })
  });
  toast("Stav uložen");
  closeModal();
  loadFaktury();
}

async function deleteFaktura(id) {
  if (!confirm("Opravdu smazat tuto fakturu?")) return;
  await api(`/api/faktury/${id}`, { method: "DELETE" });
  toast("Faktura smazána");
  closeModal();
  loadFaktury();
}

function exportFaktury(fmt) {
  const params = new URLSearchParams({
    format: fmt,
    firma: document.getElementById("fFirma")?.value || "",
    stav:  document.getElementById("fStav")?.value  || "",
    od:    document.getElementById("fOd")?.value    || "",
    do:    document.getElementById("fDo")?.value    || "",
  });
  window.location.href = `/api/export/faktury?${params}`;
}

// ═══════════════════════════════════════════════════════════════
//  NAHRÁT FAKTURU (MAKRO)
// ═══════════════════════════════════════════════════════════════
let uploadedFilePath = null;

function renderNahrat() {
  document.getElementById("mainContent").innerHTML = `
    <div class="page-header"><h1 class="page-title">Nahrát fakturu (MAKRO)</h1></div>
    <div class="card" style="max-width:860px">
      <div class="form-group">
        <label class="form-label">Firma</label>
        <select id="nahratFirma" class="form-control" style="max-width:200px">
          ${App.config.firmy.map(f=>`<option>${f}</option>`).join("")}
        </select>
      </div>
      <div class="dropzone" id="dropzone">
        <div class="dropzone-icon">📂</div>
        <div class="dropzone-text">
          <strong>Přetáhněte sem soubor</strong> nebo klikněte pro výběr<br>
          <small>PDF (digitální faktura) nebo obrázek (fotka/sken) – max 50 MB</small>
        </div>
        <input type="file" id="fileInput" accept=".pdf,.png,.jpg,.jpeg,.tiff,.bmp">
      </div>
      <div id="uploadStatus" style="margin-top:1rem;color:var(--txt2);font-size:.9rem"></div>
      <div id="fakturaSouborPath" style="display:none"></div>

      <div id="parsedForm" style="display:none; margin-top:1.5rem;">
        <h3 style="font-family:var(--font-head);margin-bottom:1rem">Zkontrolujte a případně opravte</h3>
        <div class="grid-2" style="gap:1rem">
          <div class="form-group"><label class="form-label">Dodavatel</label><input id="pDodavatel" class="form-control" value="MAKRO Cash &amp; Carry ČR s.r.o."></div>
          <div class="form-group"><label class="form-label">Číslo faktury</label><input id="pCislo" class="form-control"></div>
          <div class="form-group"><label class="form-label">Datum vystavení</label><input type="date" id="pDatVys" class="form-control"></div>
          <div class="form-group"><label class="form-label">Datum splatnosti</label><input type="date" id="pDatSpl" class="form-control"></div>
          <div class="form-group"><label class="form-label">Způsob úhrady</label><input id="pUhrada" class="form-control"></div>
          <div class="form-group"><label class="form-label">Stav</label>
            <select id="pStav" class="form-control">
              <option value="ceka">Čeká na zaplacení</option>
              <option value="zaplaceno">Zaplaceno</option>
            </select>
          </div>
        </div>
        <h4 style="font-family:var(--font-head);margin:1rem 0 .7rem">Položky</h4>
        <div class="table-wrap" style="overflow-x:auto">
          <table class="items-table" id="polozkyTable">
            <thead><tr><th>Název</th><th>Množství</th><th>Jednotka</th><th>Cena/jedn. s DPH</th><th>Celkem s DPH</th><th></th></tr></thead>
            <tbody id="polozkyBody"></tbody>
          </table>
        </div>
        <button class="btn btn-secondary btn-sm" style="margin-top:.5rem" onclick="addPolozkaRow()">+ Přidat položku</button>
        <div style="margin-top:1rem;font-weight:600;font-size:1.05rem" id="totalSum"></div>
        <div class="btn-group" style="margin-top:1.2rem">
          <button class="btn btn-primary" onclick="ulozitFakturuMakro()">💾 Uložit fakturu</button>
        </div>
      </div>
    </div>`;

  setupDropzone();
}

function setupDropzone() {
  const dz   = document.getElementById("dropzone");
  const inp  = document.getElementById("fileInput");

  dz.addEventListener("click", () => inp.click());
  inp.addEventListener("change", () => { if (inp.files[0]) uploadFile(inp.files[0]); });

  dz.addEventListener("dragover", e => { e.preventDefault(); dz.classList.add("drag-over"); });
  dz.addEventListener("dragleave", () => dz.classList.remove("drag-over"));
  dz.addEventListener("drop", e => {
    e.preventDefault(); dz.classList.remove("drag-over");
    if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]);
  });
}

async function uploadFile(file) {
  document.getElementById("uploadStatus").innerHTML = `<span class="spinner"></span> Nahrávám a zpracovávám…`;
  const fd = new FormData();
  fd.append("soubor", file);

  let data;
  try {
    const r = await fetch("/api/nahrat", { method: "POST", body: fd });
    data = await r.json();
  } catch (e) {
    document.getElementById("uploadStatus").textContent = "Chyba při nahrávání: " + e.message;
    return;
  }

  if (data.error && !data.soubor_cesta) {
    document.getElementById("uploadStatus").textContent = "❌ Chyba: " + data.error;
    return;
  }

  document.getElementById("uploadStatus").innerHTML = data.error ?
    `⚠ Soubor nahrán, ale parsování se nepodařilo (${data.error}). Vyplňte ručně.` :
    `✅ Soubor úspěšně zpracován`;

  uploadedFilePath = data.soubor_cesta || "";

  // Vyplň formulář
  document.getElementById("parsedForm").style.display = "block";
  document.getElementById("pDodavatel").value = data.dodavatel || "MAKRO Cash & Carry ČR s.r.o.";
  document.getElementById("pCislo").value = data.cislo_faktury || "";
  document.getElementById("pDatVys").value = data.datum_vystaveni || "";
  document.getElementById("pDatSpl").value = data.datum_splatnosti || "";
  document.getElementById("pUhrada").value = data.zpusob_uhrady || "";

  // Položky
  const tbody = document.getElementById("polozkyBody");
  tbody.innerHTML = "";
  (data.polozky || []).forEach(p => appendPolozkaRow(p));
  updateTotal();
}

function appendPolozkaRow(p = {}) {
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td><input class="p-nazev" value="${escHtml(p.nazev||"")}"></td>
    <td><input class="p-mnozstvi" type="number" step="0.001" value="${p.mnozstvi||1}" style="width:80px" oninput="updateTotal()"></td>
    <td><input class="p-jednotka" value="${p.jednotka||"ks"}" style="width:55px"></td>
    <td><input class="p-cena-j" type="number" step="0.01" value="${p.cena_za_jednotku_s_dph||0}" style="width:100px" oninput="updateTotal()"></td>
    <td><input class="p-celkem" type="number" step="0.01" value="${p.celkem_s_dph||0}" style="width:110px" oninput="updateTotal()"></td>
    <td><button class="remove-row" onclick="this.closest('tr').remove();updateTotal()">✕</button></td>`;
  document.getElementById("polozkyBody").appendChild(tr);
}

function addPolozkaRow() { appendPolozkaRow(); }

function updateTotal() {
  let t = 0;
  document.querySelectorAll("#polozkyBody tr").forEach(tr => {
    t += parseFloat(tr.querySelector(".p-celkem")?.value || 0);
  });
  const el = document.getElementById("totalSum");
  if (el) el.textContent = "Celkem s DPH: " + czMoney(t);
}

async function ulozitFakturuMakro() {
  const polozky = [];
  document.querySelectorAll("#polozkyBody tr").forEach(tr => {
    const nazev = tr.querySelector(".p-nazev")?.value.trim();
    if (!nazev) return;
    polozky.push({
      nazev,
      mnozstvi: parseFloat(tr.querySelector(".p-mnozstvi")?.value || 1),
      jednotka: tr.querySelector(".p-jednotka")?.value || "ks",
      cena_za_jednotku_s_dph: parseFloat(tr.querySelector(".p-cena-j")?.value || 0),
      celkem_s_dph: parseFloat(tr.querySelector(".p-celkem")?.value || 0),
    });
  });

  const payload = {
    firma_zkratka: document.getElementById("nahratFirma").value,
    dodavatel:     document.getElementById("pDodavatel").value,
    cislo_faktury: document.getElementById("pCislo").value,
    datum_vystaveni: document.getElementById("pDatVys").value,
    datum_splatnosti: document.getElementById("pDatSpl").value,
    zpusob_uhrady: document.getElementById("pUhrada").value,
    stav:          document.getElementById("pStav").value,
    soubor_cesta:  uploadedFilePath || "",
    zdroj:         "makro",
    polozky,
  };

  const res = await api("/api/faktury", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  });
  toast("Faktura uložena ✓");
  uploadedFilePath = null;
  navigateTo("faktury");
}

// ═══════════════════════════════════════════════════════════════
//  RUČNÍ ZADÁNÍ
// ═══════════════════════════════════════════════════════════════
function renderRucni() {
  document.getElementById("mainContent").innerHTML = `
    <div class="page-header"><h1 class="page-title">Ruční zadání faktury</h1></div>
    <div class="card" style="max-width:860px">
      <div class="grid-2" style="gap:1rem">
        <div class="form-group"><label class="form-label">Firma *</label>
          <select id="rFirma" class="form-control">
            ${App.config.firmy.map(f=>`<option>${f}</option>`).join("")}
          </select>
        </div>
        <div class="form-group"><label class="form-label">Dodavatel *</label><input id="rDodavatel" class="form-control" placeholder="Název firmy dodavatele"></div>
        <div class="form-group"><label class="form-label">Číslo faktury</label><input id="rCislo" class="form-control"></div>
        <div class="form-group"><label class="form-label">Způsob úhrady</label><input id="rUhrada" class="form-control" placeholder="převodem / hotově"></div>
        <div class="form-group"><label class="form-label">Datum vystavení</label><input type="date" id="rDatVys" class="form-control"></div>
        <div class="form-group"><label class="form-label">Datum splatnosti</label><input type="date" id="rDatSpl" class="form-control"></div>
        <div class="form-group"><label class="form-label">Stav</label>
          <select id="rStav" class="form-control">
            <option value="ceka">Čeká na zaplacení</option>
            <option value="zaplaceno">Zaplaceno</option>
          </select>
        </div>
        <div class="form-group"><label class="form-label">Příloha (volitelné)</label>
          <input type="file" id="rSoubor" class="form-control" accept=".pdf,.png,.jpg,.jpeg">
        </div>
      </div>
      <h4 style="font-family:var(--font-head);margin:1rem 0 .7rem">Položky</h4>
      <div class="table-wrap">
        <table class="items-table">
          <thead><tr><th>Název</th><th>Množství</th><th>Jednotka</th><th>Cena/jedn. s DPH</th><th>Celkem s DPH</th><th></th></tr></thead>
          <tbody id="rPolozkyBody">
            <tr>
              <td><input class="p-nazev" placeholder="Název položky"></td>
              <td><input class="p-mnozstvi" type="number" step="0.001" value="1" style="width:80px" oninput="rUpdateTotal();rCalcCena(this)"></td>
              <td><input class="p-jednotka" value="ks" style="width:55px"></td>
              <td><input class="p-cena-j" type="number" step="0.01" value="0" style="width:100px" oninput="rUpdateTotal();rCalcCelkem(this)"></td>
              <td><input class="p-celkem" type="number" step="0.01" value="0" style="width:110px" oninput="rUpdateTotal()"></td>
              <td><button class="remove-row" onclick="this.closest('tr').remove();rUpdateTotal()">✕</button></td>
            </tr>
          </tbody>
        </table>
      </div>
      <button class="btn btn-secondary btn-sm" style="margin-top:.5rem" onclick="rAddRow()">+ Přidat položku</button>
      <div style="margin-top:1rem;font-weight:600" id="rTotal"></div>
      <div class="btn-group" style="margin-top:1.2rem">
        <button class="btn btn-primary" onclick="ulozitRucni()">💾 Uložit fakturu</button>
        <button class="btn btn-secondary" onclick="navigateTo('faktury')">Zrušit</button>
      </div>
    </div>`;
  rUpdateTotal();
}

function rAddRow() {
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td><input class="p-nazev" placeholder="Název položky"></td>
    <td><input class="p-mnozstvi" type="number" step="0.001" value="1" style="width:80px" oninput="rUpdateTotal();rCalcCelkem(this)"></td>
    <td><input class="p-jednotka" value="ks" style="width:55px"></td>
    <td><input class="p-cena-j" type="number" step="0.01" value="0" style="width:100px" oninput="rUpdateTotal();rCalcCelkem(this)"></td>
    <td><input class="p-celkem" type="number" step="0.01" value="0" style="width:110px" oninput="rUpdateTotal()"></td>
    <td><button class="remove-row" onclick="this.closest('tr').remove();rUpdateTotal()">✕</button></td>`;
  document.getElementById("rPolozkyBody").appendChild(tr);
}

function rCalcCelkem(inp) {
  const tr = inp.closest("tr");
  const mn = parseFloat(tr.querySelector(".p-mnozstvi").value||1);
  const cj = parseFloat(tr.querySelector(".p-cena-j").value||0);
  tr.querySelector(".p-celkem").value = (mn*cj).toFixed(2);
  rUpdateTotal();
}
function rCalcCena(inp) {
  const tr = inp.closest("tr");
  const mn = parseFloat(tr.querySelector(".p-mnozstvi").value||1);
  const ce = parseFloat(tr.querySelector(".p-celkem").value||0);
  if (mn) tr.querySelector(".p-cena-j").value = (ce/mn).toFixed(4);
  rUpdateTotal();
}

function rUpdateTotal() {
  let t = 0;
  document.querySelectorAll("#rPolozkyBody tr").forEach(tr => {
    t += parseFloat(tr.querySelector(".p-celkem")?.value || 0);
  });
  const el = document.getElementById("rTotal");
  if (el) el.textContent = "Celkem s DPH: " + czMoney(t);
}

async function ulozitRucni() {
  const dodavatel = document.getElementById("rDodavatel").value.trim();
  if (!dodavatel) { toast("Vyplňte dodavatele", true); return; }

  // Nahrání přílohy
  let soubor_cesta = "";
  const soubFile = document.getElementById("rSoubor").files[0];
  if (soubFile) {
    const fd = new FormData(); fd.append("soubor", soubFile);
    try {
      const r = await fetch("/api/nahrat", { method:"POST", body:fd });
      const d = await r.json();
      soubor_cesta = d.soubor_cesta || "";
    } catch(e) { toast("Chyba nahrávání přílohy: " + e.message, true); }
  }

  const polozky = [];
  document.querySelectorAll("#rPolozkyBody tr").forEach(tr => {
    const nazev = tr.querySelector(".p-nazev")?.value.trim();
    if (!nazev) return;
    polozky.push({
      nazev,
      mnozstvi: parseFloat(tr.querySelector(".p-mnozstvi")?.value||1),
      jednotka: tr.querySelector(".p-jednotka")?.value||"ks",
      cena_za_jednotku_s_dph: parseFloat(tr.querySelector(".p-cena-j")?.value||0),
      celkem_s_dph: parseFloat(tr.querySelector(".p-celkem")?.value||0),
    });
  });

  const payload = {
    firma_zkratka: document.getElementById("rFirma").value,
    dodavatel,
    cislo_faktury: document.getElementById("rCislo").value,
    datum_vystaveni: document.getElementById("rDatVys").value,
    datum_splatnosti: document.getElementById("rDatSpl").value,
    zpusob_uhrady: document.getElementById("rUhrada").value,
    stav: document.getElementById("rStav").value,
    soubor_cesta,
    zdroj: "rucni",
    polozky,
  };

  await api("/api/faktury", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify(payload)
  });
  toast("Faktura uložena ✓");
  navigateTo("faktury");
}

// ═══════════════════════════════════════════════════════════════
//  ZBOŽÍ / POLOŽKY
// ═══════════════════════════════════════════════════════════════
async function renderPolozky() {
  document.getElementById("mainContent").innerHTML = `
    <div class="page-header">
      <h1 class="page-title">Přehled zboží</h1>
      <div class="btn-group">
        <button class="btn btn-secondary btn-sm" onclick="exportPolozky('xlsx')">⬇ Excel</button>
        <button class="btn btn-secondary btn-sm" onclick="exportPolozky('csv')">⬇ CSV</button>
      </div>
    </div>
    <div class="filters">
      <label>Firma:</label>
      <select id="pFirma" class="firma-select">
        <option value="">Všechny</option>
        ${App.config.firmy.map(f=>`<option>${f}</option>`).join("")}
      </select>
      <label>Od:</label><input type="date" id="pOd">
      <label>Do:</label><input type="date" id="pDo">
    </div>
    <div class="card">
      <div class="table-wrap" id="polozkyList"><div class="loading-center"><span class="spinner"></span></div></div>
    </div>`;

  loadPolozky();
  ["pFirma","pOd","pDo"].forEach(id => {
    document.getElementById(id)?.addEventListener("change", loadPolozky);
  });
}

async function loadPolozky() {
  const params = new URLSearchParams({
    firma: document.getElementById("pFirma")?.value||"",
    od:    document.getElementById("pOd")?.value||"",
    do:    document.getElementById("pDo")?.value||"",
  });
  let rows;
  try { rows = await api(`/api/polozky?${params}`); } catch { return; }

  const el = document.getElementById("polozkyList");
  if (!el) return;
  el.innerHTML = `
    <table>
      <thead><tr><th>Zboží</th><th>Jedn.</th><th>Celk. množství</th><th>Celkem s DPH</th><th>Průměrná cena/jedn.</th><th>Nákupů</th><th>Dodavatelé</th></tr></thead>
      <tbody>
        ${rows.map(r => `
          <tr class="zbozi-row" data-id="${r.zbozi_id||""}" data-nazev="${escHtml(r.zbozi_nazev)}">
            <td><strong>${escHtml(r.zbozi_nazev)}</strong></td>
            <td>${r.jednotka}</td>
            <td>${Number(r.celkove_mnozstvi).toLocaleString("cs-CZ")}</td>
            <td><strong>${czMoney(r.celkem_utraceno)}</strong></td>
            <td>${czMoney(r.prumerna_cena)}</td>
            <td>${r.pocet_nakupu}</td>
            <td style="font-size:.82rem;color:var(--txt2)">${escHtml(r.dodavatele||"")}</td>
          </tr>`).join("") ||
          "<tr><td colspan='7' style='text-align:center;color:var(--txt2);padding:2rem'>Žádné položky</td></tr>"}
      </tbody>
    </table>`;

  document.querySelectorAll(".zbozi-row").forEach(r => {
    r.addEventListener("click", () => {
      if (r.dataset.id) openZboziDetail(r.dataset.id, r.dataset.nazev);
    });
  });
}

async function openZboziDetail(zbozi_id, nazev) {
  let data;
  try { data = await api(`/api/polozky/detail/${zbozi_id}`); } catch { return; }

  // Načti všechna zboží pro dropdown slučování
  const vsechnaZbozi = await api("/api/zbozi").catch(() => []);
  const zboziOpts = vsechnaZbozi.map(z =>
    `<option value="${z.id}" ${z.id == zbozi_id ? "selected" : ""}>${escHtml(z.nazev_canonical)}</option>`
  ).join("");

  const body = `
    <h4 style="margin-bottom:.5rem">${escHtml(data.zbozi.nazev_canonical)}</h4>
    <div class="alias-list" id="aliasContainer">
      ${data.aliasy.map(a => `<span class="alias-tag">${escHtml(a)}</span>`).join("")}
    </div>
    <div style="margin-top:1rem; display:flex; gap:.5rem; flex-wrap:wrap;">
      <input id="newAlias" class="form-control" style="max-width:250px" placeholder="Nový alias (alternativní název)">
      <button class="btn btn-secondary btn-sm" onclick="addAlias(${zbozi_id})">+ Přidat alias</button>
    </div>
    <hr style="margin:1rem 0; border-color:var(--border)">
    <h4 style="font-family:var(--font-head);margin-bottom:.7rem">Historie nákupů</h4>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Datum</th><th>Dodavatel</th><th>Firma</th><th>Množství</th><th>Cena/jedn.</th><th>Celkem</th></tr></thead>
        <tbody>
          ${data.nakupy.map(n => `
            <tr>
              <td>${czDate(n.datum_vystaveni)}</td>
              <td>${escHtml(n.dodavatel)}</td>
              <td>${n.firma_zkratka}</td>
              <td>${Number(n.mnozstvi).toLocaleString("cs-CZ")} ${n.jednotka}</td>
              <td>${czMoney(n.cena_za_jednotku_s_dph)}</td>
              <td><strong>${czMoney(n.celkem_s_dph)}</strong></td>
            </tr>`).join("") || "<tr><td colspan='6' style='text-align:center;color:var(--txt2)'>Žádné nákupy</td></tr>"}
        </tbody>
      </table>
    </div>`;

  openModal(`Detail zboží: ${escHtml(nazev)}`, body);
}

async function addAlias(zbozi_id) {
  const alias = document.getElementById("newAlias").value.trim();
  if (!alias) { toast("Vyplňte alias", true); return; }
  await api("/api/zbozi/alias", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ zbozi_id, alias })
  });
  toast("Alias přidán");
  const el = document.getElementById("aliasContainer");
  el.innerHTML += `<span class="alias-tag">${escHtml(alias)}</span>`;
  document.getElementById("newAlias").value = "";
}

function exportPolozky(fmt) {
  const params = new URLSearchParams({
    format: fmt,
    firma: document.getElementById("pFirma")?.value||"",
    od:    document.getElementById("pOd")?.value||"",
    do:    document.getElementById("pDo")?.value||"",
  });
  window.location.href = `/api/export/polozky?${params}`;
}

// ═══════════════════════════════════════════════════════════════
//  STATISTIKY
// ═══════════════════════════════════════════════════════════════
async function renderStatistiky() {
  // Výchozí rozsah: posledních 12 měsíců
  const od = new Date(); od.setFullYear(od.getFullYear()-1);
  const odStr = od.toISOString().split("T")[0];
  const doStr = new Date().toISOString().split("T")[0];

  document.getElementById("mainContent").innerHTML = `
    <div class="page-header"><h1 class="page-title">Statistiky</h1></div>
    <div class="filters" style="margin-bottom:1rem">
      <label>Firma:</label>
      <select id="sFirma" class="firma-select">
        <option value="">Všechny</option>
        ${App.config.firmy.map(f=>`<option>${f}</option>`).join("")}
      </select>
      <label>Od:</label><input type="date" id="sOd" value="${odStr}">
      <label>Do:</label><input type="date" id="sDo" value="${doStr}">
      <button class="btn btn-primary btn-sm" onclick="loadStatistiky()">Zobrazit</button>
    </div>
    <div id="statContent"><div class="loading-center"><span class="spinner"></span></div></div>`;

  loadStatistiky();
}

async function loadStatistiky() {
  const params = new URLSearchParams({
    firma: document.getElementById("sFirma")?.value||"",
    od:    document.getElementById("sOd")?.value||"",
    do:    document.getElementById("sDo")?.value||"",
  });
  let data;
  try { data = await api(`/api/statistiky?${params}`); } catch { return; }

  const el = document.getElementById("statContent");
  if (!el) return;

  el.innerHTML = `
    <div class="grid-2" style="gap:1rem; margin-bottom:1rem">
      <div class="card">
        <div class="card-title">Výdaje po měsících</div>
        <div class="chart-wrap"><canvas id="sBarChart" style="width:100%;height:100%"></canvas></div>
      </div>
      <div class="card">
        <div class="card-title">Top dodavatelé</div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Dodavatel</th><th>Faktur</th><th>Celkem</th></tr></thead>
            <tbody>
              ${data.dodavatele.map(d=>`
                <tr><td>${escHtml(d.dodavatel)}</td><td>${d.pocet}</td><td><strong>${czMoney(d.castka)}</strong></td></tr>
              `).join("") || "<tr><td colspan='3' style='text-align:center;color:var(--txt2)'>Žádná data</td></tr>"}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-title">Nejnakupovanější zboží (dle výdajů)</div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Zboží</th><th>Celkem s DPH</th><th>Množství</th><th>Jedn.</th></tr></thead>
          <tbody>
            ${data.zbozi_top.map(z=>`
              <tr>
                <td>${escHtml(z.zbozi)}</td>
                <td><strong>${czMoney(z.castka)}</strong></td>
                <td>${Number(z.mnozstvi).toLocaleString("cs-CZ")}</td>
                <td>${z.jednotka}</td>
              </tr>`).join("") || "<tr><td colspan='4' style='text-align:center;color:var(--txt2)'>Žádná data</td></tr>"}
          </tbody>
        </table>
      </div>
    </div>`;

  requestAnimationFrame(() => {
    drawBarChart("sBarChart", data.mesice.map(m=>m.mesic), data.mesice.map(m=>m.castka));
  });
}

// ═══════════════════════════════════════════════════════════════
//  NASTAVENÍ
// ═══════════════════════════════════════════════════════════════
async function renderNastaveni() {
  const cfg = await api("/api/config").catch(()=>App.config);
  document.getElementById("mainContent").innerHTML = `
    <div class="page-header"><h1 class="page-title">Nastavení</h1></div>
    <div class="card" style="max-width:520px">
      <div class="form-group">
        <label class="form-label">Název aplikace</label>
        <input id="cfgNazev" class="form-control" value="${escHtml(cfg.app_nazev)}">
      </div>
      <div class="form-group">
        <label class="form-label">Zkratky firem (oddělte čárkou)</label>
        <input id="cfgFirmy" class="form-control" value="${escHtml((cfg.firmy||[]).join(", "))}">
        <small style="color:var(--txt2)">Příklad: ABC, XYZ, DEF</small>
      </div>
      <button class="btn btn-primary" onclick="saveConfig()">💾 Uložit nastavení</button>
    </div>`;
}

async function saveConfig() {
  const nazev = document.getElementById("cfgNazev").value.trim();
  const firmy = document.getElementById("cfgFirmy").value.split(",").map(s=>s.trim()).filter(Boolean);
  if (!firmy.length) { toast("Zadejte alespoň jednu firmu", true); return; }
  await api("/api/config", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ app_nazev: nazev, firmy })
  });
  await loadConfig();
  toast("Nastavení uloženo");
}

// ═══════════════════════════════════════════════════════════════
//  Util
// ═══════════════════════════════════════════════════════════════
function escHtml(s) {
  return String(s||"")
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
}
